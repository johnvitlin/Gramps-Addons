#
# PDF Thumbnailer - A PDF thumbnail generator for Gramps
#
# Copyright (C) 2026 John Vitlin
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.
#

from gramps.gen.const import GRAMPS_LOCALE as glocale

_ = glocale.translation.gettext

register(  # pyright: ignore[reportUndefinedVariable]
    THUMBNAILER,  # pyright: ignore[reportUndefinedVariable]
    id="pdfthumbnailer",
    name=_("PDF Thumbnailer"),
    description=_("Generate PDF thumbnails using Ghostscript or Poppler"),
    version="0.1.1",
    gramps_target_version="6.0",
    status=STABLE,  # pyright: ignore[reportUndefinedVariable]
    order=START,  # pyright: ignore[reportUndefinedVariable]
    fname="PDFThumbnailer.py",
    thumbnailer="PDFThumbnailer",
    authors=["John Vitlin"],
)
