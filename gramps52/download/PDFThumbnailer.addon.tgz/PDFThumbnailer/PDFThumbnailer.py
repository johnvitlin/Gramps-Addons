#
# PDF Thumbnailer - A PDF thumbnail generator for Gramps
#
# Copyright (C) 2026 John Vitlin
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.
#

"""
PDF thumbnail generation using Ghostscript or Poppler.
"""

import logging
import os
import shutil
import subprocess
import tempfile
from functools import lru_cache
from pathlib import Path

from gramps.gen.const import THUMBSCALE, THUMBSCALE_LARGE, SIZE_LARGE
from gramps.gen.plug import Thumbnailer

LOG = logging.getLogger(".thumbnail")


# Cache the Ghostscript executable path to avoid repeated searches.
@lru_cache(maxsize=1)
def find_ghostscript():
    """Locate the Ghostscript executable."""

    if os.name == "nt":
        return (
            shutil.which("gswin64c")
            or shutil.which("gswin32c")
            or shutil.which("gs")
        )

    return shutil.which("gs")


# Cache the Poppler executable path to avoid repeated searches.
@lru_cache(maxsize=1)
def find_pdftoppm():
    """Locate Poppler's pdftoppm executable."""

    configured = os.environ.get("PDFTHUMBNAILER_PDFTOPPM")

    if configured:
        if os.path.isfile(configured):
            return configured
        LOG.warning(
            "Configured Poppler executable not found: %s",
            configured,
        )

    executable = shutil.which("pdftoppm")
    if executable:
        return executable

    # Search common Windows Poppler installation directories.
    if os.name == "nt":
        roots = [
            Path("C:/Poppler"),
            Path(os.environ.get("ProgramFiles", "C:/Program Files")) / "Poppler",
            Path(os.environ.get("ProgramFiles(x86)", "C:/Program Files (x86)")) / "Poppler",
            Path("C:/Tools/Poppler"),
        ]

        local_app_data = os.environ.get("LOCALAPPDATA")
        if local_app_data:
            roots.append(Path(local_app_data) / "Poppler")

        for root in roots:
            candidates = [
                root / "Library/bin/pdftoppm.exe",
                root / "bin/pdftoppm.exe",
            ]

            if root.is_dir():
                try:
                    for version_dir in root.iterdir():
                        if version_dir.is_dir():
                            candidates.extend([
                                version_dir / "Library/bin/pdftoppm.exe",
                                version_dir / "bin/pdftoppm.exe",
                            ])
                except OSError as err:
                    LOG.debug(
                        "Cannot search Poppler directory %s: %s",
                        root, err,
                    )

            for candidate in candidates:
                if candidate.is_file():
                    return str(candidate)

    return None


def render_poppler(pdftoppm, src_file, output_prefix, thumbscale):
    """Render the first page of a PDF using Poppler."""

    command = [
        pdftoppm,
        "-f", "1",
        "-l", "1",
        "-singlefile",
        "-scale-to", str(int(thumbscale)),
        "-png",
        src_file,
        output_prefix,
    ]

    subprocess.run(
        command,
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        timeout=30,
    )


def render_ghostscript(gs, src_file, output_prefix, thumbscale):
    """Render the first page of a PDF using Ghostscript and Pillow."""

    # Import Pillow locally so Poppler can operate without it.
    from PIL import Image

    output_png = output_prefix + ".png"

    command = [
        gs,
        "-dSAFER",
        "-dBATCH",
        "-dNOPAUSE",
        "-dFirstPage=1",
        "-dLastPage=1",
        "-sDEVICE=png16m",
        "-r72",
        f"-sOutputFile={output_png}",
        src_file,
    ]

    subprocess.run(
        command,
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        timeout=30,
    )

    # Support both newer and older Pillow versions.
    resampling = getattr(Image, "Resampling", Image)

    # Resize while preserving the original page aspect ratio.
    try:
        with Image.open(output_png) as img:
            img.thumbnail(
                (int(thumbscale), int(thumbscale)),
                resampling.LANCZOS,
            )
            img.save(output_png, "PNG")

    except Image.DecompressionBombError as err:
        raise OSError(
            "Rendered PDF page exceeds Pillow's image size limit"
        ) from err


class PDFThumbnailer(Thumbnailer):
    """Generate a PNG thumbnail from the first page of a PDF."""

    def is_supported(self, mime_type):
        return mime_type == "application/pdf"

    def run(self, mime_type, src_file, dest_file, size, rectangle):
        if not self.is_supported(mime_type):
            return False

        thumbscale = (
            THUMBSCALE_LARGE if size == SIZE_LARGE else THUMBSCALE
        )

        # Try Ghostscript first, then Poppler.
        renderers = (
            ("Ghostscript", find_ghostscript, render_ghostscript),
            ("Poppler", find_pdftoppm, render_poppler),
        )

        for name, find_executable, render in renderers:
            executable = find_executable()

            if not executable:
                continue

            try:
                with tempfile.TemporaryDirectory() as temp_dir:
                    output_prefix = os.path.join(temp_dir, "pdf-thumb")
                    output_png = output_prefix + ".png"

                    render(
                        executable,
                        src_file,
                        output_prefix,
                        thumbscale,
                    )

                    os.replace(output_png, dest_file)

                LOG.debug("PDF thumbnail generated using %s", name)
                return True

            except (OSError, subprocess.SubprocessError, ImportError) as err:
                LOG.warning(
                    "PDF thumbnail generation using %s failed: %s",
                    name, err,
                )

        LOG.warning(
            "PDF thumbnail could not be generated using "
            "Ghostscript or Poppler. Check that at least one "
            "renderer is installed and working correctly."
        )
        return False
